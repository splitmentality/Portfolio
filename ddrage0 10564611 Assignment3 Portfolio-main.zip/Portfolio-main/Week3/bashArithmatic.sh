#!/bin/bash
#ddrage0 Week3.2
#Basic Arithmetic functions: Bash

echo "Let's add two numbers"
read "val_1"
read "val_2"

echo `expr $val_1 + $val_2`

#https://www.google.com/search?q=bash+syntax+addition&oq=bash+syntax+addition&aqs=chrome..69i57.4695j0j15&sourceid=chrome&ie=UTF-8
#https://www.youtube.com/watch?v=GU50rQz0b9g


