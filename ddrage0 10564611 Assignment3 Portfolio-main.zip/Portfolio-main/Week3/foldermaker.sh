#ddrage0@bash: foldermaker.sh

#!/bin/bash
# creates new folder
# DDrage0 28/01/2022

   
read -p "type the name of the folder you would like to create" folderName 
      
mkdir "$folderName" 

exit 0

