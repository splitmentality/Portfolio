#!/bin/bash
#ddrage0 Week3.3 Fruit Loop
# 05/02/2022

food=(Apple Mango Strawberry Orange Banana)

for f in "${food[@]}"

do

    echo FRUIT: $f

done