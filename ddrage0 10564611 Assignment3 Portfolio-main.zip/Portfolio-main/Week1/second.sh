#!/bin/bash 
      
echo "Hi there!" 
      
echo "It's good to see you $1!" 
echo "I am $2 years old"
exit 0
     