#!/bin/bash
echo "Hello from nano!"
exit 0
≈
