#!/bin/bash
echo "Hello from emacs!"

exit 0
