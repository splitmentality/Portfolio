#!/bin/bash
echo "Hello from vim!"

exit 0



